import React from "react";

const EditContactDialog = () => {
  return <div>EditContactDialog</div>;
};

export default EditContactDialog;
